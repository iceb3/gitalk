export const GT_ACCESS_TOKEN = 'GT_ACCESS_TOKEN'
export const GT_VERSION = VERSION // eslint-disable-line
export const GT_COMMENT = 'GT_COMMENT'
